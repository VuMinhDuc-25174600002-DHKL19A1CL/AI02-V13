@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  set "PY=.venv\Scripts\python.exe"
) else if exist "..\.venv\Scripts\python.exe" (
  set "PY=..\.venv\Scripts\python.exe"
) else (
  set "PY=python"
)
echo Dung Python: %PY%
echo Mo giao dien tai: http://localhost:8501
"%PY%" -m streamlit run app.py
if errorlevel 1 (
  echo [LOI] Khong chay duoc Streamlit. Thu cai: 
  echo "%PY%" -m pip install -r requirements.txt -r requirements_cnn.txt
  pause
)
