@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
set "TARGET=D:\UNETI12_ODD3_AI02_V3_RA_SOAT_KY\UNETI12_ODD3_AI02"
echo ================================================
echo   SMART CAMPUS AI - GIAO DIEN V11 DE NHIN
echo ================================================
echo.
set /p "USERPATH=Duong dan du an AI02 (Enter dung mac dinh): "
if not "%USERPATH%"=="" set "TARGET=%USERPATH%"
set "TARGET=%TARGET:"=%"
if not exist "%TARGET%\inference_bridge.py" (
 echo [LOI] Khong tim thay inference_bridge.py. Can chon thu muc V9/V10 dung.
 pause
 exit /b 1
)
if not exist "%TARGET%\src\predict.py" (
 echo [LOI] Thieu src\predict.py trong du an da chon.
 pause
 exit /b 1
)
if not exist "%~dp0app.py" (
 echo [LOI] Thieu app.py trong bo cap nhat.
 pause
 exit /b 1
)
if not exist "%TARGET%\backup_ui" mkdir "%TARGET%\backup_ui"
for /f %%a in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "STMP=%%a"
if not defined STMP set "STMP=backup"
if exist "%TARGET%\app.py" copy /Y "%TARGET%\app.py" "%TARGET%\backup_ui\app_%STMP%.py" >nul
copy /Y "%~dp0app.py" "%TARGET%\app.py" >nul
if errorlevel 1 goto fail
copy /Y "%~dp0ui_v10_utils.py" "%TARGET%\ui_v10_utils.py" >nul
if errorlevel 1 goto fail
copy /Y "%~dp001_CHAY_WEB_V11.bat" "%TARGET%\01_CHAY_WEB_V11.bat" >nul
if errorlevel 1 goto fail
if not exist "%TARGET%\.streamlit" mkdir "%TARGET%\.streamlit"
copy /Y "%~dp0.streamlit\config.toml" "%TARGET%\.streamlit\config.toml" >nul
if errorlevel 1 goto fail
echo.
echo [OK] Da cap nhat giao dien V11 vao:
echo %TARGET%
echo Du lieu, model, ket qua va code huan luyen khong bi thay doi.
echo Tat ung dung Streamlit cu va chay 01_CHAY_WEB_V11.bat.
pause
exit /b 0
:fail
echo [LOI] Khong the sao chep file. Kiem tra quyen ghi va duong dan.
pause
exit /b 1
