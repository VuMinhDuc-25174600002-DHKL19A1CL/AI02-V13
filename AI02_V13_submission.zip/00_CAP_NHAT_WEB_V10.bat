@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo SMART CAMPUS AI02 - CAP NHAT GIAO DIEN V10
echo ============================================
set "TARGET=D:\UNETI12_ODD3_AI02_V3_RA_SOAT_KY\UNETI12_ODD3_AI02"
set /p "USERPATH=Nhap duong dan project AI02 cu (Enter dung mac dinh): "
if not "%USERPATH%"=="" set "TARGET=%USERPATH%"
set "TARGET=%TARGET:"=%"
if not exist "%TARGET%\inference_bridge.py" (
  echo [LOI] Khong tim thay inference_bridge.py. Hay cai V9 truoc hoac dung dung thu muc project.
  pause
  exit /b 1
)
if not exist "%TARGET%\cnn_utils.py" (
  echo [LOI] Thieu cnn_utils.py trong project cu.
  pause
  exit /b 1
)
if not exist "%~dp0app.py" (
  echo [LOI] Thieu app.py trong bo V10.
  pause
  exit /b 1
)
if not exist "%TARGET%\backup_v10" mkdir "%TARGET%\backup_v10"
if exist "%TARGET%\app.py" if not exist "%TARGET%\backup_v10\app.py" copy /Y "%TARGET%\app.py" "%TARGET%\backup_v10\app.py" >nul
copy /Y "%~dp0app.py" "%TARGET%\app.py" >nul
if errorlevel 1 goto fail
copy /Y "%~dp0ui_v10_utils.py" "%TARGET%\ui_v10_utils.py" >nul
if errorlevel 1 goto fail
copy /Y "%~dp001_CHAY_WEB_V10.bat" "%TARGET%\01_CHAY_WEB_V10.bat" >nul
if errorlevel 1 goto fail
if not exist "%TARGET%\.streamlit" mkdir "%TARGET%\.streamlit"
if not exist "%TARGET%\.streamlit\config.toml" copy /Y "%~dp0.streamlit\config.toml" "%TARGET%\.streamlit\config.toml" >nul
echo.
echo [OK] DA CAP NHAT GIAO DIEN V10 vao:
echo %TARGET%
echo Khong ghi de data, model, results hoac ma huan luyen.
echo De chay web, mo file 01_CHAY_WEB_V10.bat trong project cu.
pause
exit /b 0
:fail
echo [LOI] Khong the sao chep file. Kiem tra quyen ghi thu muc.
pause
exit /b 1
