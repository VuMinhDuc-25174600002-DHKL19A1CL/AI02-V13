@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo ==========================================
echo AI02 V9 - CAP NHAT MO HINH + GIAO DIEN
 echo ==========================================
set "TARGET=D:\UNETI12_ODD3_AI02_V3_RA_SOAT_KY\UNETI12_ODD3_AI02"
set /p "USERPATH=Nhap thu muc project cu (ENTER dung mac dinh): "
if not "%USERPATH%"=="" set "TARGET=%USERPATH%"
set "TARGET=%TARGET:"=%"
if not exist "%TARGET%\src\predict.py" (
 echo [LOI] Khong tim thay src\predict.py tai "%TARGET%"
 pause
 exit /b 1
)
if not exist "%TARGET%\requirements.txt" (
 echo [LOI] Khong tim thay requirements.txt
 pause
 exit /b 1
)
if not exist "%TARGET%\backup_before_v9" mkdir "%TARGET%\backup_before_v9"
for %%F in (app.py ui_v10_utils.py 01_CHAY_WEB_V10.bat inference_bridge.py cnn_utils.py train_cnn.py requirements_cnn.txt) do (
 if exist "%TARGET%\%%F" if not exist "%TARGET%\backup_before_v9\%%F" copy /Y "%TARGET%\%%F" "%TARGET%\backup_before_v9\%%F" >nul
)
for %%F in (app.py ui_v10_utils.py 01_CHAY_WEB_V10.bat inference_bridge.py cnn_utils.py train_cnn.py compare_results.py compare_results_v9.py requirements_cnn.txt kiem_tra_model_v9.py 08_HUAN_LUYEN_V9_B2.bat 09_HUAN_LUYEN_V9_CONVNEXT.bat 10_KIEM_TRA_V9.bat 11_SO_SANH_V4_V9.bat README_V9.md) do (
 if not exist "%~dp0%%F" (
  echo [LOI] Thieu %%F trong bo V9
  pause
  exit /b 1
 )
 copy /Y "%~dp0%%F" "%TARGET%\%%F" >nul
 if errorlevel 1 (
   echo [LOI] Chep %%F that bai
   pause
   exit /b 1
 )
)
if not exist "%TARGET%\.streamlit" mkdir "%TARGET%\.streamlit"
if not exist "%TARGET%\.streamlit\config.toml" copy /Y "%~dp0.streamlit\config.toml" "%TARGET%\.streamlit\config.toml" >nul
echo.
echo [OK] Da cap nhat V9 + WEB V10 vao "%TARGET%"
echo Du lieu / model / results cu van duoc giu nguyen.
echo Chay 08_HUAN_LUYEN_V9_B2.bat tai thu muc project de huan luyen.
pause
